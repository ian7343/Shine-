import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

(async () => {
  const db = await open({
    filename: './weddings.db',
    driver: sqlite3.Database
  });

  await db.exec('DROP TABLE IF EXISTS venues');
  await db.exec('DROP TABLE IF EXISTS planners');

  await db.exec(`CREATE TABLE venues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    state TEXT,
    location TEXT,
    price_category TEXT,
    indoor BOOLEAN,
    outdoor BOOLEAN,
    all_inclusive BOOLEAN,
    offers TEXT,
    website TEXT,
    contact TEXT
  )`);

  await db.exec(`CREATE TABLE planners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    state TEXT,
    services TEXT,
    pricing TEXT,
    reviews TEXT
  )`);

  await db.run(`INSERT INTO venues (name, state, location, price_category, indoor, outdoor, all_inclusive, offers, website, contact)
    VALUES 
    ('Sunset Gardens', 'Nevada', 'Las Vegas', 'Medium', 1, 1, 1, 'Catering,Photography,Decor', 'https://sunsetgardens.com', 'info@sunsetgardens.com'),
    ('Ocean View Hall', 'California', 'Santa Monica', 'High', 1, 1, 0, 'Catering,Beach Access', 'https://oceanviewhall.com', 'contact@oceanviewhall.com')
  `);

  await db.run(`INSERT INTO planners (name, state, services, pricing, reviews)
    VALUES 
    ('Elegant Weddings Co.', 'Nevada', 'Full Service Planning,Day Of Coordination', '$2000-$5000', '5 stars by 120 clients'),
    ('Golden Gate Weddings', 'California', 'Venue Scouting,Vendor Management', '$3000-$7000', '4.8 stars by 95 clients')
  `);

  console.log('Database seeded!');
  process.exit(0);
})();
