import express from 'express';
import cors from 'cors';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

const app = express();
app.use(cors());
app.use(express.json());

let db;
(async () => {
  db = await open({
    filename: './weddings.db',
    driver: sqlite3.Database
  });
})();

app.get('/api/venues', async (req, res) => {
  const venues = await db.all('SELECT * FROM venues');
  res.json(venues);
});

app.get('/api/planners', async (req, res) => {
  const planners = await db.all('SELECT * FROM planners');
  res.json(planners);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
